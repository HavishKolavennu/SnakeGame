package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

class Snake extends Polygon {
  private final double step; 

  Snake(Point[] headShape, Point start, double startRotation,
        double stepPixels, int ignoredTurnDegrees) {
    super(headShape, start, startRotation);
    this.step = stepPixels;
  }

  //Method to always move forward in current direction
  void move() {
    double rad = Math.toRadians(rotation);
    position.x += step * Math.cos(rad);
    position.y += step * Math.sin(rad);
  }

  //Draws arrow head 
  void paint(Graphics g) {
    Point[] pts = getPoints();
    int[] xs = new int[pts.length];
    int[] ys = new int[pts.length];
    for (int i = 0; i < pts.length; i++) {
      xs[i] = (int)Math.round(pts[i].x);
      ys[i] = (int)Math.round(pts[i].y);
    }
    g.setColor(new Color(20, 220, 20));
    g.fillPolygon(xs, ys, pts.length);
    g.setColor(Color.BLACK);
    g.drawPolygon(xs, ys, pts.length); 
  }

  // Inner class: WASD and their directions
  class MovementHandler implements KeyListener {
    @Override public void keyPressed(KeyEvent e) {
      int k = e.getKeyCode();
      if (k == KeyEvent.VK_D) rotation = 0;     // right
      if (k == KeyEvent.VK_S) rotation = 90;    // down
      if (k == KeyEvent.VK_A) rotation = 180;   // left
      if (k == KeyEvent.VK_W) rotation = 270;   // up
    }
    @Override public void keyReleased(KeyEvent e) {  }
    @Override public void keyTyped(KeyEvent e) { }
  }
}
