package game;

import java.awt.*;
import java.awt.event.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

class SnakeGame extends Game implements GameGrid {
  private final Random rng = new Random();
  private final double[][] grid;
  private final int cols, rows, cell;

  private Snake snake;
  //private final List<Apple> apples = new ArrayList<>();
  //private final List<Wall>  walls  = new ArrayList<>();

  private boolean running = true;
  private int score = 0;
  static int counter = 0;

  public SnakeGame() {
    super("Snake Game", 800, 600);

    this.cell = 20;
    this.cols = width / cell;
    this.rows = height / cell;
    this.grid = new double[rows][cols];

    Point[] head = new Point[] {
      new Point(0, 4),   new Point(18, 4),
      new Point(18, 0),  new Point(30, 9),
      new Point(18, 18), new Point(18, 14),
      new Point(0, 14)
    };

    snake = new Snake(
      head,
      new Point(width / 2.0, height / 2.0),
      0.0,   // facing right
      3.0,   // step per tick
      0      // turnDegrees (unused now)
    );

    //Movement input
    this.addKeyListener(snake.new MovementHandler());

    //Anonymous class: toggle pause by pressing letter P
    this.addKeyListener(new KeyAdapter() {
      @Override public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_P) running = !running;
      }
    });

    spawnRandomWalls(3);
   // spawnApple();
   // spawnApple();

    setFocusable(true);
    this.requestFocus();
  }

  @Override
  public void paint(Graphics brush) {
    //Checkerboard background
    drawCheckerboard(brush);

    brush.setColor(Color.white);
    brush.drawString("Counter is " + (++counter), 10, 16);
    brush.drawString("Score: " + score, 10, 32);
    brush.drawString("[W][A][S][D] change direction   [P] pause", 10, 48);

    if (running) {
      snake.move();         // always moving
      wrap(snake);
      //checkAppleEaten();
      if (hitWall()) running = false;
    }

   // walls.forEach(w -> w.paint(brush));
    //apples.forEach(a -> a.paint(brush));
    snake.paint(brush);

    if (!running) {
      brush.setColor(new Color(255, 60, 60));
      brush.drawString("GAME OVER - Press P to view", width/2 - 60, height/2);
    }
  }

  //Background
  private void drawCheckerboard(Graphics g) {
    final int tile = 40; // tile size
    final Color dark = new Color(35, 0, 55);  // dark purple
    final Color light = new Color(65, 0, 95); // light purple
    for (int y = 0; y < height; y += tile) {
      for (int x = 0; x < width; x += tile) {
        boolean even = (((x / tile) + (y / tile)) % 2) == 0;
        g.setColor(even ? dark : light);
        g.fillRect(x, y, tile, tile);
      }
    }
  }

  private void spawnRandomWalls(int count) {
    for (int i = 0; i < count; i++) {
      int len = 120 + rng.nextInt(160);
      double x = 40 + rng.nextInt(Math.max(1, width - len - 80));
      double y = 80 + rng.nextInt(Math.max(1, height - 160));
      //walls.add(new Wall(new Point(x, y), len));
    }
  }

  /*private void spawnApple() {
    Apple.Kind kind;
    int r = rng.nextInt(3);
    if (r == 0) kind = Apple.Kind.RED();
    else if (r == 1) kind = Apple.Kind.GREEN();
    else kind = Apple.Kind.GOLD();

    Point pos = new Point(
      20 + rng.nextInt(width - 40),
      80 + rng.nextInt(height - 120)
    );
    apples.add(new Apple(kind, pos, rng.nextInt(360)));
  }*/

  /*private void checkAppleEaten() {
    apples.removeIf(a -> {
      boolean collide = polygonsCollide(snake, a);
      if (collide) {
        score += a.getValue();
        spawnApple();
      }
      return collide;
    });
  }*/

  private boolean hitWall() {
    //for (Wall w : walls) if (polygonsCollide(snake, w)) return true;
    return false;
  }

  private static boolean polygonsCollide(Polygon a, Polygon b) {
    for (Point p : a.getPoints()) if (b.contains(p)) return true;
    for (Point p : b.getPoints()) if (a.contains(p)) return true;
    return false;
  }

  void wrap(Polygon p) {
    if (p.position.x < 0)          p.position.x += width;
    if (p.position.x > width)      p.position.x -= width;
    if (p.position.y < 0)          p.position.y += height;
    if (p.position.y > height)     p.position.y -= height;
  }

  @Override public int cols() { return cols; }
  @Override public int rows() { return rows; }
  @Override public int cellSize() { return cell; }
  @Override public Color colorAt(int r, int c) { return Color.DARK_GRAY; }
  @Override public double[][] grid() { return grid; }

  public static void main(String[] args) {
    SnakeGame a = new SnakeGame();
    a.repaint();
  }
}
