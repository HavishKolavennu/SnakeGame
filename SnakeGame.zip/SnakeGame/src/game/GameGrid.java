package game;

import java.awt.Color;

public interface GameGrid {
  int cols();
  int rows();
  int cellSize();
  Color colorAt(int r, int c);
  double[][] grid();
}
